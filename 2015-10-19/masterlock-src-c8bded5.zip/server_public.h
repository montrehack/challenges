extern unsigned char g_server_public_bin[33];
