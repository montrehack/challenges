extern const char *g_host;
extern const char *g_port;

void ping();
