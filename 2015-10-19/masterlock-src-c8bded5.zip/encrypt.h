extern char g_banner[1024];

void initbanner();
void encryptall(char *path);
