#!/usr/bin/env python3


from pathlib import Path
from secrets import randbelow
import sys

global KEY_FILE

def get_key_blob():
    return KEY_FILE.read_bytes()


def perform_crypt(offset_A, offset_B, data):

    key_blob = get_key_blob()
    crypt_data = bytearray(len(data))

    key_len = len(key_blob)
    for i, b in enumerate(data):
        crypt_data[i] = b ^ key_blob[(i + offset_A) % key_len] ^ key_blob[(i + offset_B) % key_len]
    return crypt_data

def crypt_file(in_file):
    key_blob = get_key_blob()
    offset_A = randbelow(len(key_blob))
    offset_B = randbelow(len(key_blob))
    
    file_data = perform_crypt(offset_A, offset_B, in_file.read_bytes())

    new_file_name = f'{in_file.name}_{offset_A}_{offset_B}'
    
    out_f = in_file.parent / new_file_name
    out_f.write_bytes(file_data)
    print(out_f)
    
def decrypt_file(in_file):
    *name_components, A, B = in_file.name.split('_')
    offset_A, offset_B = int(A), int(B)

    data = perform_crypt(offset_A, offset_B, in_file.read_bytes())
    
    out_f = in_file.parent / ('_'.join(name_components) + '.decrypted')
    out_f.write_bytes(data)
    print(out_f)
    
def main():
    global KEY_FILE
    c_arg = sys.argv[1]
    KEY_FILE = Path(sys.argv[2])
    if c_arg == 'decrypt':
        fn = decrypt_file
    else:
        fn = crypt_file

    for f in sys.argv[3:]:
        print(f'processing {f}')
        fn(Path(f))

if __name__ == '__main__':
    main()
